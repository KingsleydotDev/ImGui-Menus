# PrismUI
Easy C++ optional framework for interface implementation
![image](https://user-images.githubusercontent.com/69056284/117117644-76851700-ad98-11eb-9d6f-63f106923c2f.png)
