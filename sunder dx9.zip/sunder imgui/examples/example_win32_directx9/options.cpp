#include "options.hpp"

Options opt;