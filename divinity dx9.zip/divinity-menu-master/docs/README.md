# Divinity menu
Menu was never pushed to prod, some things might be unfinished/buggy as was never fully completed. 
50 stars for more releases
<br>
Preview - 


![image](https://raw.githubusercontent.com/current/divinity-menu/master/misc/menu.png?token=GHSAT0AAAAAACM6RUGBFLFWK2PLSMMKTZM4ZOOJYUQ)
