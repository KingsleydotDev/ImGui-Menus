#pragma once

namespace ImGui
{
	void HelpMarker(const char* fmt, ...);
}
