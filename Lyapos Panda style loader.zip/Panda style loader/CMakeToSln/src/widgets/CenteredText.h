#pragma once

namespace ImGui {
void CenteredText(const char *fmt, ...);
}
