#ifndef ICOMOON_ICONS_H
#define ICOMOON_ICONS_H

#define ICON_G1218 "\ue948"
#define ICON_G16514 "\ue94c"
#define ICON_G16830 "\ue955"
#define ICON_G16840 "\ue959"
#define ICON_G16878 "\ue965"
#define ICON_G18110 "\ue95d"
#define ICON_G19238 "\ue960"
#define ICON_G19258 "\ue963"
#define ICON_MATERIAL_SYMBOLS_NOT_STARTED_ROUNDED "\ue969"
#define ICON_VECTOR "\ue96a"
#define ICON_TG "\ue96b"
#define ICON_ARROWS_RIGHT_LINE "\ue947"
#define ICON_SUN_1 "\ue940"
#define ICON_MOON_STARS_1 "\ue943"
#define ICON_MINIMIZE_LINE "\ue945"
#define ICON_CLOSE_LINE_1 "\ue946"
#define ICON_RESHOT_ICON_FOREST_LEAF_LSCJ9B4X6H "\ue93e"
#define ICON_CANNABIS_LEAF_SVGREPO_COM "\ue918"
#define ICON_BAMBOO_SVGREPO_COM_1 "\ue900"
#define ICON_BELL_BADGE "\ue90e"
#define ICON_LOADING_3_FILL "\ue910"
#define ICON_LOGO "\ue912"
#define ICON_ALERT_TRIANGLE_1 "\ue914"
#define ICON_APPROVED_1 "\ue916"

#include <unordered_map>
#include <vector>
#include <cstdint>

static std::unordered_map<uint32_t, std::vector<uint32_t>> g_icon_colors {
{0xE948, {ImGui::ColorConvertFloat4ToU32({0.0F, 0.0F, 0.0F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.192F, 0.824F, 0.969F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.533F, 0.424F, 0.894F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.0F, 0.0F, 0.0F, 1.F})}},
{0xE94C, {ImGui::ColorConvertFloat4ToU32({0.0F, 0.0F, 0.0F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.733F, 0.569F, 0.404F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.847F, 0.69F, 0.58F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.969F, 0.843F, 0.769F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.459F, 0.459F, 0.459F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.8F, 0.8F, 0.8F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.22F, 0.22F, 0.22F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.898F, 0.898F, 0.898F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.91F, 0.071F, 0.141F, 1.F})}},
{0xE955, {ImGui::ColorConvertFloat4ToU32({0.0F, 0.0F, 0.0F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.949F, 0.949F, 0.949F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.8F, 0.8F, 0.8F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.941F, 0.227F, 0.09F, 1.F})}},
{0xE959, {ImGui::ColorConvertFloat4ToU32({0.0F, 0.0F, 0.0F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.949F, 0.949F, 0.949F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.8F, 0.8F, 0.8F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.0F, 0.471F, 0.843F, 1.F})}},
{0xE965, {ImGui::ColorConvertFloat4ToU32({0.0F, 0.0F, 0.0F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.855F, 0.231F, 0.004F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.898F, 0.898F, 0.898F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.941F, 0.227F, 0.09F, 1.F})}},
{0xE95D, {ImGui::ColorConvertFloat4ToU32({0.0F, 0.0F, 0.0F, 1.F}), ImGui::ColorConvertFloat4ToU32({1.0F, 1.0F, 1.0F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.0F, 0.737F, 0.949F, 1.F})}},
{0xE960, {ImGui::ColorConvertFloat4ToU32({0.0F, 0.0F, 0.0F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.086F, 0.776F, 0.047F, 1.F}), ImGui::ColorConvertFloat4ToU32({1.0F, 1.0F, 1.0F, 1.F})}},
{0xE963, {ImGui::ColorConvertFloat4ToU32({0.0F, 0.0F, 0.0F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.941F, 0.227F, 0.09F, 1.F})}},
{0xE947, {ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 1.F})}},
{0xE940, {ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 0.3F}), ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 1.F})}},
{0xE943, {ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 0.3F}), ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 1.F})}},
{0xE945, {ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 1.F})}},
{0xE946, {ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 1.F})}},
{0xE93E, {ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.667F, 0.82F, 0.365F, 1.F})}},
{0xE918, {ImGui::ColorConvertFloat4ToU32({0.451F, 0.741F, 0.325F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.451F, 0.741F, 0.325F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.451F, 0.741F, 0.325F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.451F, 0.741F, 0.325F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.424F, 0.714F, 0.298F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.424F, 0.714F, 0.298F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.424F, 0.714F, 0.298F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}),
ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.514F, 0.702F, 0.329F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.016F, 0.0F, 0.0F, 0.06F}), ImGui::ColorConvertFloat4ToU32({0.424F, 0.714F, 0.298F, 1.F})}},
{0xE900, {ImGui::ColorConvertFloat4ToU32({0.494F, 0.69F, 0.267F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.443F, 0.592F, 0.275F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.537F, 0.741F, 0.212F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.486F, 0.639F, 0.224F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.537F, 0.741F, 0.212F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.486F, 0.639F, 0.224F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.729F, 0.894F, 0.275F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.686F, 0.843F, 0.263F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.729F, 0.894F, 0.275F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.686F, 0.843F, 0.263F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.729F, 0.894F, 0.275F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.686F, 0.843F, 0.263F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.729F, 0.894F, 0.275F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.686F, 0.843F, 0.263F, 1.F})}},
{0xE90E, {ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 0.3F}),
ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 1.F})}},
{0xE910, {ImGui::ColorConvertFloat4ToU32({0.035F, 0.141F, 0.294F, 0.1F}), ImGui::ColorConvertFloat4ToU32({0.035F, 0.141F, 0.294F, 1.F})}},
{0xE912, {ImGui::ColorConvertFloat4ToU32({0.878F, 0.878F, 0.878F, 1.F}), ImGui::ColorConvertFloat4ToU32({0.184F, 0.184F, 0.184F, 1.F})}},
{0xE914, {ImGui::ColorConvertFloat4ToU32({1.0F, 0.0F, 0.0F, 0.3F}), ImGui::ColorConvertFloat4ToU32({1.0F, 0.0F, 0.0F, 1.F})}},
{0xE96A, {ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 1.F})}},
{0xE96B, {ImGui::ColorConvertFloat4ToU32({0.565F, 0.718F, 0.294F, 1.F})}},
{0xE916, {ImGui::ColorConvertFloat4ToU32({0.0F, 1.0F, 0.039F, 0.3F}), ImGui::ColorConvertFloat4ToU32({0.0F, 1.0F, 0.039F, 1.F})}}

};
#endif // ICOMOON_ICONS_H
