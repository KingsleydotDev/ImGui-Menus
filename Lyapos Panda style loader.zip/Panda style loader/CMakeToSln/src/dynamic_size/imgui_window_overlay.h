#pragma once

#include <iostream>
#include "imgui.h"

static inline ImVec2 main_window_pos;

inline bool window_move_detector;

/*void move_window();
void RenderBlur(HWND hwnd);*/
