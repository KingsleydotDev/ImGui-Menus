//
// Created by n08i40k on 10.04.2024.
//

#ifndef BUBBLECHECKBOX_H
#define BUBBLECHECKBOX_H

namespace ImGui {
bool
BubbleCheckbox(const char* label,
               bool* v);
}

#endif //BUBBLECHECKBOX_H
