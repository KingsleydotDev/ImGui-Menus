//
// Created by n08i40k on 06.05.2024.
//

#ifndef IMGUI_ANIMATION_MANAGER_H
#define IMGUI_ANIMATION_MANAGER_H

#include "animation_manager.h"

using imgui_animation_manager [[deprecated]] = ngui::animation_manager;

#ifdef __clang__
#warning "Использование устаревшего заголовочного файла imgui_animation_manager.h"
#endif

#endif //IMGUI_ANIMATION_MANAGER_H
