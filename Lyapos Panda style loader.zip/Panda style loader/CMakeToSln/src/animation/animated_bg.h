//
// Created by Lyapos on 02.05.2024.
//

#ifndef IMGUI_TEMPLATE_SRC_ANIMATION_WIDGETS_ANIMATED_BG_H
#define IMGUI_TEMPLATE_SRC_ANIMATION_WIDGETS_ANIMATED_BG_H

#include <vector>
#include <random>

#include "imgui.h"
#include "imgui_internal.h"

#include "animation/imgui_animation_manager.h"
#include "animation/linear/linear_button_color_animation.h"
#include "animation/linear/linear_color_animation.h"
#include "render/RenderCheckMarkRotated.h"
#include "widgets/TextWithDescription.h"
#include "widgets/ColoredText.h"
#include "widgets/CenteredText.h"
#include "dynamic_size/imgui_dynamic_size.h"
#include "fonts/icomoon_icons.h"

#include "animation/linear/linear_with_target_2d_animation.h"
#include "animation/linear/linear_with_target_animation.h"

class AnimatedBackground {
public:


private:

};

#endif //IMGUI_TEMPLATE_SRC_ANIMATION_WIDGETS_ANIMATED_BG_H
