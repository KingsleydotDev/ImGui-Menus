#pragma once

#include "imgui_addons.h"

namespace ImGrp
{
	void	Checkbox(const char* label, bool* v);
	
	void    ColorEdit4(const char* label, float col[4]);
}